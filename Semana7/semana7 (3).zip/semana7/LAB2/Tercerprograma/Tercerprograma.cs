﻿using System.ComponentModel;

namespace proyect2
{
    class proyect2
    {
         static void Main(string[] args)
         {
            Console.WriteLine("Calculo de velocidad final");
            double Vi = 0;
            double Vf = 0;
            double ac = 0;
            double t = 0;

            Console.WriteLine("Ingrese el valor de velocidad incial");
            Vi = double.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese el valor de aceleración");
            ac = double.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese el valor de tiempo");
            t = double.Parse(Console.ReadLine());

            Vf = Vi * ac * t; 
            Console.WriteLine("La velocidad final es " + Vf);
            Console.ReadKey(); 
            
            /*PROYECTO 2*/
            Console.WriteLine("Equivalencias");
            Console.WriteLine("Ingrese una cantidad en quetzales (entre 0 y 999.99):");
            double cantidad = double.Parse(Console.ReadLine());

            int centavos = (int)(cantidad * 100);
            int billetes100 = centavos / 10000;
            centavos %= 10000;
            int billetes50 = centavos / 5000;
            centavos %= 5000;
            int billetes20 = centavos / 2000;
            centavos %= 2000;
            int billetes10 = centavos / 1000;
            centavos %= 1000;
            int billetes5 = centavos / 500;
            centavos %= 500;
            int monedas1 = centavos / 100;
            centavos %= 100;
            int monedas25 = centavos / 25;
            centavos %= 25;

            Console.WriteLine("Billetes de 100 quetzales: " + billetes100);
            Console.WriteLine("Billetes de 50 quetzales: " + billetes50);
            Console.WriteLine("Billetes de 20 quetzales: " + billetes20);
            Console.WriteLine("Billetes de 10 quetzales: " + billetes10);
            Console.WriteLine("Billetes de 5 quetzales: " + billetes5);
            Console.WriteLine("Monedas de 1 quetzal: " + monedas1);
            Console.WriteLine("Monedas de 25 centavos: " + monedas25);
            Console.WriteLine("Monedas de 1 centavo: " + centavos);

         }
    }
}
