﻿namespace segundoprograma
{
    class segundoprograma
    {
        static void Main(string[] args)
        {
            string sNombre = "";
            string sEdad = "";
            string sCarrera = "";
            string sCarne = "";

            Console.WriteLine("Hola ingrese su nombre");
            sNombre = Console.ReadLine();
            Console.WriteLine("Ingrese su edad");
            sEdad = Console.ReadLine();
            Console.WriteLine("Ingrese su carrera");
            sCarrera = Console.ReadLine();
            Console.WriteLine("Ingrese su carnet");
            sCarne = Console.ReadLine();

            Console.WriteLine("Soy " + sNombre + ", tengo " + sEdad + " años de edad y estudio la carrera de " + sCarrera + ". Mi número de carnet es " + sCarne);
            Console.ReadKey();
        }
    }
}