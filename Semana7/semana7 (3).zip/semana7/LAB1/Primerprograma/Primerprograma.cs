﻿namespace proyect1
{
    class proyect1
    {
         static void Main(string[] args)
        {
                       /* PROCESOS B Y C*/
            Console.WriteLine("Hola mundo soy Gabriel  Emilio Toyom Jimenez");
            Console.ReadKey();
            /* PROCESOS D Y E*/
            Console.WriteLine("Hola Mundo");
            Console.WriteLine("Soy Gabriel Emilio Toyom Jimenez");

            /*COMENTARIOS*/
            Console.WriteLine("Hola Mundo");
            Console.WriteLine("Soy Gabriel Emilio Toyom Jimenez");
            Console.ReadKey();

            /* PROCESO F*/
            Console.WriteLine("Ingrese su nombre");
            String Nombre = Console.ReadLine();

            Console.Write("Hola Mundo");
            Console.WriteLine(" soy " + Nombre);

            /* COMENTARIOS */
            Console.Write("Hola Mundo ");
            Console.Write("soy "  + Nombre );
            Console.WriteLine("\n");
            Console.ReadKey();
        }
    }
}