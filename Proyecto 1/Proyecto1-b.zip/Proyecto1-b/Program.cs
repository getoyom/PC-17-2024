﻿namespace proyecto1
{
    class proyecto1
    {
        static void Main(string[] args)
        { 
            Console.WriteLine("Bienvenido a la banca virtual del Banco Country"); 
            bool Salir = false;
            do
            {
                Console.WriteLine("Seleccione el número de la opción que desea ejecutar");
                Console.WriteLine("1. Ingresar a cuenta");
                Console.WriteLine("2. Comprar Producto");
                Console.WriteLine("3. Vender Producto");
                Console.WriteLine("4. Abonar a cuenta");
                Console.WriteLine("5. Simular paso del tiempo");
                Console.WriteLine("6. Salir");
                string opciones = Console.ReadLine();
                switch (opciones)
                {
                    case "1":
                        {

                            break;
                        }
                    case "2":
                        {

                            break;
                        }
                    case "3":
                        {

                            break;
                        }
                    case "4":
                        {

                            break;
                        }
                    case "5":
                        {

                            break;
                        }
                    case "6":
                        {
                            Salir = true;
                            Console.WriteLine("Gracias por utilizar nuestros servicios");
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("Opción no valida, seleccionar otra opción");
                            break;
                        }
                }
            }
            while (!Salir);
        }
    }
}