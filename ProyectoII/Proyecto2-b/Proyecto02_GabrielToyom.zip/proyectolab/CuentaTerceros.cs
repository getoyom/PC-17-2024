
using ProyectoII;

//CLASE CONTRUCCION DE CUENTA DE TERCEROS
class ConsCuenta
{
    // DECLARACION DE VARIABLES Y ARREGLOS
    public string PropietarioCuenta { get; set; }
    public int IdCuenta { get; private set; }
    public string NombreBanco { get; set; }
    public double MontoCuenta = 0;
    public double tranferencia;
    public string Moneda { get; private set; }

    private static string[,] listaCuentas = new string[5, 10];
    private static int contadorCuentas = 1;

    //SOLICITUD DE DATOS
    public void SolicitarCuenta()
    {
        System.Console.WriteLine("-----SOLICITAR CUENTA DE TERCEROS-----");
        System.Console.WriteLine("Ingrese nombre del propietario");
        PropietarioCuenta = Console.ReadLine();

        IdCuenta = contadorCuentas;
        System.Console.WriteLine($"Su identificador es {IdCuenta}");
        System.Console.WriteLine("Ingrese nombre del banco");
        NombreBanco = Console.ReadLine();
        System.Console.WriteLine($"La cantidad que usted ha depositado a la cuenta es de {MontoCuenta}");
        Moneda = "Quetzales";

        // Agregar la cuenta a listaCuentas
        listaCuentas[0, IdCuenta - 1] = IdCuenta.ToString();
        listaCuentas[1, IdCuenta - 1] = PropietarioCuenta;
        listaCuentas[2, IdCuenta - 1] = NombreBanco;
        listaCuentas[3, IdCuenta - 1] = MontoCuenta.ToString();
        listaCuentas[4, IdCuenta - 1] = Moneda;

        contadorCuentas++;
        MostrarCuentas();
    }

    //MOSTRAR CUENTAS DE TERCEROS
    public void MostrarCuentas()
    {
        System.Console.WriteLine("Listado de Cuentas:");
        System.Console.WriteLine("----------------------");

        for (int k = 0; k < contadorCuentas - 1; k++)
        {
            System.Console.WriteLine($"ID: {listaCuentas[0, k]}, Propietario: {listaCuentas[1, k]}, Banco: {listaCuentas[2, k]}, Monto: {listaCuentas[3, k]}, Moneda: {listaCuentas[4, k]}");
        }

        System.Console.WriteLine("----------------------");
    }

    //MENU DE MANTENIMIENTO
    public void MenuMantenimiento()
    {
        bool continuar = true;
        while (continuar)
        {
            System.Console.WriteLine("-------MENÚ DE OPCIONES PARA CUENTA DE TERCEROS-----");
            System.Console.WriteLine("Seleccione la opción a realizar:");
            System.Console.WriteLine("a) Editar cuenta de tercero");
            System.Console.WriteLine("b) Eliminar cuenta de terceros");
            System.Console.WriteLine("c) Volver al menú principal");
            char opcion = Console.ReadLine().ToLower()[0];

            switch (opcion)
            {
                case 'a':
                    System.Console.WriteLine("Seleccione el id de la cuenta que desea editar");
                    int idEditar = Convert.ToInt32(Console.ReadLine());
                    EditarCuenta(idEditar);
                    break;
                case 'b':
                    System.Console.WriteLine("Seleccione el id de la cuenta que desea eliminar");
                    int idEliminar = Convert.ToInt32(Console.ReadLine());
                    EliminarCuenta(idEliminar);
                    break;
                case 'c':
                    System.Console.WriteLine("Se le retornara al menú principal");
                    continuar = false;
                    break;
                default:
                    Console.WriteLine("Ingrese una opción válida");
                    break;
            }
        }
    }

    //EDICIÓN DE CUENTA DE TERCEROS
    private void EditarCuenta(int id)
    {
        for (int k = 0; k < contadorCuentas - 1; k++)
        {
            if (listaCuentas[0, k] == id.ToString())
            {
                System.Console.WriteLine($"Editando cuenta con ID {id}");
                System.Console.WriteLine("Ingrese nuevo nombre del propietario:");
                PropietarioCuenta = Console.ReadLine();
                System.Console.WriteLine("Ingrese nuevo nombre del banco:");
                NombreBanco = Console.ReadLine();
                System.Console.WriteLine("Se ha reiniciado el monto depositado de la cuenta:");
                MontoCuenta = 0;

                // Actualizar la cuenta en listaCuentas
                listaCuentas[1, k] = PropietarioCuenta;
                listaCuentas[2, k] = NombreBanco;
                listaCuentas[3, k] = MontoCuenta.ToString();

                MostrarCuentas();
                return;
            }
        }
        System.Console.WriteLine("Cuenta no encontrada.");
    }
    
    //ELIMINACIÓN DE CUENTAS DE TERCEROS
    private void EliminarCuenta(int id)
    {
        for (int k = 0; k < contadorCuentas - 1; k++)
        {
            if (listaCuentas[0, k] == id.ToString())
            {
                // Eliminar la cuenta de listaCuentas
                for (int j = 0; j < 5; j++)
                {
                    listaCuentas[j, contadorCuentas - 1] = null;
                }
                contadorCuentas--;
                MostrarCuentas();
                return;
            }
        }
        System.Console.WriteLine("Cuenta no encontrada.");
    }

    //TRANSFERENCIA A CUENTAS DE TERCEROS
    public void Tranferir()
    {

        System.Console.WriteLine("Seleccione el id de la cuenta a la que se desea realizar el deposito");
        int IdTranferencia = Convert.ToInt32(Console.ReadLine());
        for (int k = 0; k < contadorCuentas - 1; k++)
        {
            if (listaCuentas[0, k] == IdTranferencia.ToString())
            {
                System.Console.WriteLine("Ingrese la cantidad que desea tranferir");
                MontoCuenta = Convert.ToDouble(Console.ReadLine());
                Program.saldoCuenta -= MontoCuenta;
                listaCuentas[3, k] = MontoCuenta.ToString();

                MostrarCuentas();
                System.Console.WriteLine("La transferencia se a realizado con exito!");

                double Monto = MontoCuenta;
                DateTime Fecha = DateTime.Now;
                string Notas = $"Transferencia a la cuenta con ID:{IdTranferencia}";
                var TransferenciaTerceros = new Transaccion(-Monto, Fecha, Notas);
                Program._todaslasTransacciones.Add(TransferenciaTerceros);
                return;
            }
        }
        System.Console.WriteLine("Cuenta no encontrada.");
    }
}
