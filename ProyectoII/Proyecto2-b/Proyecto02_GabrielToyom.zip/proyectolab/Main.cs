using System.Text.RegularExpressions;
/*Realizado por:
 Gabriel Emilio Toyom Jimenez 1051524*/

namespace ProyectoII
{
    /*Clase principal Program*/
    class Program
    {
        /*Declaración de variables*/
        static string tipoCuenta;
        static string nombre;
        static string dpi;
        static string direccion;
        static int numeroTelefono;
        public static double saldoCuenta { get; set; } = 2500;
        static int numeroAbonos;
        public static List<Transaccion> _todaslasTransacciones = new List<Transaccion>();

        /*MAIN*/
        static void Main()
        {
            Menu();
        }
        /*METODO MENU*/
        static void Menu()
        {
            System.Console.WriteLine("------------------------------------------------");
            System.Console.WriteLine("Bienvenido a la banca virtual del Banco Country");
            System.Console.WriteLine("------------------------------------------------");
            System.Console.WriteLine("Ingrese su información");

            ObtenerInformacionCliente();

            bool salir = false;
            do
            {
                System.Console.WriteLine("------------------------MENU-----------------------");
                System.Console.WriteLine("Seleccione el número de la opción que desea ejecutar");
                System.Console.WriteLine("a. Consultar información de cuenta");
                System.Console.WriteLine("b. Comprar producto");
                System.Console.WriteLine("c. Vender producto");
                System.Console.WriteLine("d. Abonar a cuenta");
                System.Console.WriteLine("e. Simular paso del tiempo");
                System.Console.WriteLine("f. Mantenimiento de cuenta de tercero");
                System.Console.WriteLine("g. Transferencias a otras cuentas");
                System.Console.WriteLine("h. Pago de servicios");
                System.Console.WriteLine("i. Mostrar informe de transacciones");
                System.Console.WriteLine("j. Salir");

                char opcion = Console.ReadLine().ToLower()[0];
                switch (opcion)
                {
                    case 'a':
                        ConsultarInformacionCuenta();
                        break;
                    case 'b':
                        ComprarProducto();
                        break;
                    case 'c':
                        VenderProducto();
                        break;
                    case 'd':
                        AbonarCuenta();
                        break;
                    case 'e':
                        SimularPasoTiempo();
                        break;
                    case 'f':
                        ConsCuenta MantenimientoCuenta = new ConsCuenta();
                        MantenimientoCuenta.SolicitarCuenta();
                        MantenimientoCuenta.MenuMantenimiento();
                        break;
                    case 'g':
                        ConsCuenta Transferir = new ConsCuenta();
                        Transferir.Tranferir();
                        break;
                    case 'h':
                        PagoServicios();
                        break;
                    case 'i':
                        ObtenerHistorial();
                        break;
                    case 'j':
                        salir = true;
                        System.Console.WriteLine("Gracias por utilizar nuestros servicios");
                        break;
                    default:
                        System.Console.WriteLine("Opción no válida, seleccione el número de la opción que desea visualizar");
                        break;
                }
            } while (!salir);
        }

        /*Metodo para obtener la información del cliente*/
        static void ObtenerInformacionCliente()
        {
            System.Console.WriteLine("Ingrese su tipo de cuenta:");
            System.Console.WriteLine("a. Monetaria en Q");
            System.Console.WriteLine("b. Ahorro en Q");
            System.Console.WriteLine("c. Monetaria en $");
            System.Console.WriteLine("d. Ahorro en $");

            char tipoCuentaInput = Console.ReadLine().ToLower()[0];
            switch (tipoCuentaInput)
            {
                case 'a':
                    tipoCuenta = "Monetaria en Q";
                    break;
                case 'b':
                    tipoCuenta = "Ahorro en Q";
                    break;
                case 'c':
                    tipoCuenta = "Monetaria en $";
                    break;
                case 'd':
                    tipoCuenta = "Ahorro en $";
                    break;
                default:
                    System.Console.WriteLine("Tipo de cuenta no válido");
                    ObtenerInformacionCliente();
                    break;
            }

            System.Console.WriteLine("Ingrese su nombre:");
            nombre = Console.ReadLine();
            EsAlfabetico(nombre);

            while (EsAlfabetico(nombre) == false)
            {
                System.Console.WriteLine("Se han agregado valores no permitidos, porfavor vuelva a ingresar el nombre");
                nombre = Console.ReadLine();
            }

            System.Console.WriteLine("Ingrese su DPI (5 caracteres):");
            dpi = Console.ReadLine();

            while (dpi.Length != 5)
            {
                System.Console.WriteLine("Por favor, ingrese un DPI de 5 caracteres:");
                dpi = Console.ReadLine();
            }

            System.Console.WriteLine("Ingrese su dirección:");
            direccion = Console.ReadLine();

            System.Console.WriteLine("Ingrese su número de teléfono:");
            while (!int.TryParse(Console.ReadLine(), out numeroTelefono))
            {
                Console.WriteLine("Por favor, ingrese un valor numérico de 8 caracteres para el número de teléfono:");
            }

        }

        /*Validación para valores alfabeticos*/
        static bool EsAlfabetico(string nombre)
        {
            // Expresión regular para verificar que la cadena solo contenga caracteres alfabéticos
            string patron = @"^[a-zA-Z]+$";
            return Regex.IsMatch(nombre, patron);
        }

        /*METODO PARA MOSTRAR INFORMACIÓN DE CUENTA PRINCIPAL*/
        static void ConsultarInformacionCuenta()
        {
            System.Console.WriteLine($"Nombre: {nombre}");
            System.Console.WriteLine($"Tipo Cuenta: {tipoCuenta}");
            System.Console.WriteLine($"DPI: {dpi}");
            System.Console.WriteLine($"Número de teléfono: {numeroTelefono}");
            System.Console.WriteLine($"Dirección: {direccion}");
            System.Console.WriteLine($"Saldo Actual: {saldoCuenta}");
        }

        /*METODO PARA COMPRAR*/
        static void ComprarProducto()
        {
            double Monto = saldoCuenta * 0.1;
            saldoCuenta -= Monto;
            DateTime Fecha = DateTime.Now;
            string Notas = "Debito";
            System.Console.WriteLine($"Su saldo actual es de: {saldoCuenta}");
            var deposito = new Transaccion(-Monto, Fecha, Notas);
            _todaslasTransacciones.Add(deposito);
        }

        /*METODO PARA VENDER PRODUCTO*/
        static void VenderProducto()
        {
            double porcentaje = saldoCuenta / 100;
            if (saldoCuenta > 500)
            {
                double Monto = saldoCuenta * 0.11;
                DateTime Fecha = DateTime.Now;
                string notas = "Credito";
                saldoCuenta += Monto;
                System.Console.WriteLine($"Su saldo actual es de: {saldoCuenta}");
                var retiro = new Transaccion(Monto, Fecha, notas);
                _todaslasTransacciones.Add(retiro);
            }
            else
            {
                System.Console.WriteLine($"Se recomienda no realizar la transacción debido a que el porcentaje de su saldo actual es {porcentaje}%");
            }
        }

        /*METODO PARA ABONAR A CUENTA*/
        static void AbonarCuenta()
        {
            if (numeroAbonos < 2 && saldoCuenta > 500)
            {
                saldoCuenta *= 2;
                numeroAbonos++;
                System.Console.WriteLine($"Abono realizado con éxito, su saldo actual es {saldoCuenta}");
            }
            else
            {
                System.Console.WriteLine("Imposible realizar el abono");
            }
        }

        /*METODO PARA SIMULAR PASO DEL TIEMPO*/
        static void SimularPasoTiempo()
        {
            double simulador = 0;
            double suma = 0;

            System.Console.WriteLine("Simular el paso del tiempo");
            System.Console.WriteLine("¿Cuánto tiempo desea simular?");
            System.Console.WriteLine("a. 30 días");
            System.Console.WriteLine("b. 15 días");

            char sim = Console.ReadLine().ToLower()[0];
            switch (sim)
            {
                case 'a':
                    simulador = saldoCuenta * 0.02 * 30;
                    suma = simulador + saldoCuenta;
                    System.Console.WriteLine($"Su cuenta sería de {suma} a los 30 días");
                    break;
                case 'b':
                    simulador = saldoCuenta * 0.02 * 15;
                    suma = simulador + saldoCuenta;
                    System.Console.WriteLine($"Su cuenta sería de {suma} a los 15 días");
                    break;
                default:
                    System.Console.WriteLine("La opción que escogió no existe");
                    break;
            }
        }

        /*METODO PARA SELECCIONAR PAGO DE SERVICIOS*/
        static void PagoServicios()
        {
            System.Console.WriteLine("------PAGO DE SERVICIOS------");
            System.Console.WriteLine("Seleccione el servicio al que desea realizar un pago:");
            System.Console.WriteLine("a) Empresa de Agua");
            System.Console.WriteLine("b) Empresa Electrica");
            System.Console.WriteLine("c) Empresa Telefonica");

            char opServicios = Console.ReadLine().ToLower()[0];

            switch (opServicios)
            {
                case 'a':
                    System.Console.WriteLine("Usted ha seleccionado empresa de agua, ingrese la cantidad que desea pagar:");
                    RealizarPagoServicio("Empresa de Agua");
                    break;
                case 'b':
                    System.Console.WriteLine("Usted ha seleccionado empresa eléctrica, ingrese la cantidad que desea pagar:");
                    RealizarPagoServicio("Empresa Eléctrica");
                    break;
                case 'c':
                    System.Console.WriteLine("Usted ha seleccionado empresa telefónica, ingrese la cantidad que desea pagar:");
                    RealizarPagoServicio("Empresa Telefónica");
                    break;
                default:
                    System.Console.WriteLine("Opción no válida");
                    break;
            }
        }

        /*METODO PARA REALIZAR PAGO DE SERVICIOS*/
        static void RealizarPagoServicio(string servicio)
        {
            if (double.TryParse(Console.ReadLine(), out double cantidad))
            {
                if (cantidad <= saldoCuenta)
                {
                    saldoCuenta -= cantidad;
                    System.Console.WriteLine($"Ha pagado Q{cantidad} al {servicio}");
                    System.Console.WriteLine($"Su saldo actual es de: {saldoCuenta}");

                    double Monto = cantidad;
                    DateTime Fecha = DateTime.Now;
                    string Notas = $"Pago de {servicio}";
                    var pagoservicio = new Transaccion(-Monto, Fecha, Notas);
                    _todaslasTransacciones.Add(pagoservicio);
                }
                else
                {
                    System.Console.WriteLine("Fondos insuficientes para realizar el pago");
                }
            }
            else
            {
                System.Console.WriteLine("Cantidad no válida");
            }
        }

        /*HISTORIAL DE MOVIMIENTOS*/
        static void ObtenerHistorial()
        {
            var reporte = new System.Text.StringBuilder();

            double balance = 2500;
            reporte.Append("-----HISTORIAL DE MOVIMIENTOS-----");
            reporte.AppendLine("\nFecha\t\t\tMonto\tBalance\tNota");
            foreach (var item in _todaslasTransacciones)
            {
                balance += item.Monto;
                reporte.AppendLine($"{item.Fecha}\t{item.Monto}\t{balance}\t{item.Nota}");
            }

            Console.WriteLine(reporte.ToString());
        }

    }
}

